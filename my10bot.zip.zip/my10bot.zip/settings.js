const settings = {
  packname: '𓆩𝐽𝑂𝐻⃟🇪🇬☭⃟𝐴𝑁⃟𓆪',
  author: '‎',
  botName: ".⤹𓆩𝐽𝑂𝐻⃟🇪🇬☭⃟𝐴𝑁⃟𓆪⤾.",
  botOwner: 'يوهان ليبرت المطور', // Your name
  ownerNumber: '201013479037', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.4",
  updateZipUrl: "https://github.com/mruniquehacker/Knightbot-MD/archive/refs/heads/main.zip",
};

module.exports = settings;
